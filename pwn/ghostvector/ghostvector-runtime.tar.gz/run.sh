#!/usr/bin/env bash
set -euo pipefail

bundle_dir=$(CDPATH= cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)

: "${SSH_PASSWORD:?set SSH_PASSWORD to the participant instance password}"
export GHOSTVECTOR_QEMU="$bundle_dir/qemu-system-riscv64"
export GHOSTVECTOR_KERNEL="$bundle_dir/Image"
export GHOSTVECTOR_INITRAMFS="$bundle_dir/initramfs.cpio.gz"
export GHOSTVECTOR_BIOS="$bundle_dir/opensbi-riscv64-generic-fw_dynamic.bin"
export GHOSTVECTOR_PASST_PATH="$bundle_dir/passt"
export SSH_LISTEN_ADDRESS="${SSH_LISTEN_ADDRESS:-0.0.0.0}"

exec "$bundle_dir/qemu-ssh-runner.sh"

