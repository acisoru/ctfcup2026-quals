#!/usr/bin/env bash
set -euo pipefail

# Common runtime for both local development and the published Docker bundle.
# The caller supplies the immutable VM artifacts through GHOSTVECTOR_* paths.

: "${GHOSTVECTOR_QEMU:?GHOSTVECTOR_QEMU is required}"
: "${GHOSTVECTOR_KERNEL:?GHOSTVECTOR_KERNEL is required}"
: "${GHOSTVECTOR_INITRAMFS:?GHOSTVECTOR_INITRAMFS is required}"

qemu=$GHOSTVECTOR_QEMU
kernel=$GHOSTVECTOR_KERNEL
initramfs=$GHOSTVECTOR_INITRAMFS
bios=${GHOSTVECTOR_BIOS:-}
passt_path=${GHOSTVECTOR_PASST_PATH:-}
ssh_password=${SSH_PASSWORD:-}
# The platform passes credentials for the inner SSH service in SSH_PASSWORD as
# user:password. Raw passwords remain accepted for local compatibility.
if [[ $ssh_password == *:* ]]; then
    case "$ssh_password" in
        user:*) ssh_password=${ssh_password#user:} ;;
        *)
            printf '%s\n' 'SSH_PASSWORD must use the guest account form user:password.' >&2
            exit 2
            ;;
    esac
fi
ssh_port=${SSH_PORT:-2222}
ssh_listen_address=${SSH_LISTEN_ADDRESS:-0.0.0.0}
serial_backend=none
passt_quiet=on
passt_debug=0
if [[ ${GHOSTVECTOR_DEBUG_SERIAL:-0} == 1 ]]; then
    # `docker run --detach` does not reliably retain QEMU's stdio stream.
    # A file is deterministic and docker-test retrieves it on failure.
    serial_log=${GHOSTVECTOR_DEBUG_SERIAL_LOG:-/tmp/ghostvector-serial.log}
    serial_backend="file:$serial_log"
    # In diagnostic mode keep both ends of the transport observable.  QEMU
    # normally asks passt to be quiet, which otherwise makes an unreachable
    # guest look like an arbitrary SSH timeout.
    passt_quiet=off
    passt_debug=1
fi

for file in "$qemu" "$kernel" "$initramfs"; do
    [[ -f $file ]] || { printf 'missing VM artifact: %s\n' "$file" >&2; exit 2; }
done
if [[ -n $bios && ! -f $bios ]]; then
    printf 'missing OpenSBI firmware: %s\n' "$bios" >&2
    exit 2
fi
if [[ -z $passt_path ]]; then
    passt_path=$(command -v passt || true)
fi
[[ -n $passt_path && -x $passt_path ]] || {
    printf '%s\n' 'passt is required for the unprivileged QEMU-to-SSH transport.' >&2
    exit 2
}
command -v openssl >/dev/null || {
    printf '%s\n' 'openssl is required to create the temporary guest password hash.' >&2
    exit 2
}
[[ -n $ssh_password && $ssh_password != *$'\n'* &&
   $ssh_password != *$'\r'* ]] || {
    printf '%s\n' 'SSH_PASSWORD must provide a non-empty, single-line password.' >&2
    exit 2
}
# Keep the clear-text password only in this shell variable until it becomes a
# salted guest hash. Do not inherit it into QEMU.
unset SSH_PASSWORD
[[ $ssh_port =~ ^[1-9][0-9]{0,4}$ ]] && (( ssh_port <= 65535 )) || {
    printf 'invalid SSH_PORT: %s\n' "$ssh_port" >&2
    exit 2
}
[[ $ssh_listen_address =~ ^([0-9]{1,3}\.){3}[0-9]{1,3}$ ]] || {
    printf 'SSH_LISTEN_ADDRESS must be an IPv4 address: %s\n' "$ssh_listen_address" >&2
    exit 2
}

flag_file=$(mktemp --tmpdir ghostvector-instance-flag.XXXXXX)
password_hash_file=$(mktemp --tmpdir ghostvector-password-hash.XXXXXX)
cleanup() {
    rm -f "$flag_file" "$password_hash_file"
}
trap cleanup EXIT INT TERM

# A detached Docker container cannot consume a reliably piped stdin. Docker
# deployments therefore provide FLAG. Some CTF platforms instead inject a flag
# file into the named service; FLAG_FILE and FLAG_FILE_WAIT_SECONDS support that
# convention without exposing the file to the RISC-V guest.
if [[ -v FLAG ]]; then
    flag=$FLAG
elif [[ -n ${FLAG_FILE:-} ]]; then
    flag_input_file=$FLAG_FILE
    flag_file_wait_seconds=${FLAG_FILE_WAIT_SECONDS:-0}
    [[ $flag_file_wait_seconds =~ ^[0-9]+$ ]] || {
        printf 'invalid FLAG_FILE_WAIT_SECONDS: %s\n' "$flag_file_wait_seconds" >&2
        exit 2
    }
    deadline=$((SECONDS + flag_file_wait_seconds))
    until [[ -r $flag_input_file ]] || (( SECONDS >= deadline )); do
        sleep 1
    done
    [[ -r $flag_input_file ]] || {
        printf 'flag file did not appear: %s\n' "$flag_input_file" >&2
        exit 2
    }
    flag=$(<"$flag_input_file")
else
    IFS= read -r flag || {
        printf '%s\n' 'expected one per-instance flag on stdin or in FLAG' >&2
        exit 2
    }
fi
unset FLAG
case "$flag" in
    ctfcup\{*\}) ;;
    *) echo 'refusing malformed flag' >&2; exit 2 ;;
esac
[[ $flag != *$'\n'* && $flag != *$'\r'* ]] || {
    echo 'refusing a multi-line flag' >&2
    exit 2
}
printf '%s' "$flag" > "$flag_file"
printf '%s' "$ssh_password" | openssl passwd -6 -stdin > "$password_hash_file"

passt_netdev="passt,id=net0,path=$passt_path,quiet=$passt_quiet,ipv4=on,ipv6=off,tcp=on,udp=off,icmp=off,tcp-ports=${ssh_listen_address}/${ssh_port}:22,param=--chroot-fallback"
if [[ $passt_debug -eq 1 ]]; then
    passt_netdev+=',param=--debug'
fi

qemu_args=(
    -machine virt
    -cpu rv64,v=true,x-ghostvector=true
    -m 256M -smp 1
    -display none -serial "$serial_backend" -monitor none -no-reboot
    -kernel "$kernel" -initrd "$initramfs"
    -append 'console=ttyS0 panic=-1 ip=dhcp'
    -fw_cfg "name=opt/ctfcup/flag,file=$flag_file"
    -fw_cfg "name=opt/ctfcup/password_hash,file=$password_hash_file"
    -netdev "$passt_netdev"
    -device virtio-net-device,netdev=net0
    -device virtio-rng-device
)
if [[ -n $bios ]]; then
    qemu_args=(-bios "$bios" "${qemu_args[@]}")
fi

printf 'GhostVector: SSH is listening on %s:%s as user user (password authentication)\n' \
    "$ssh_listen_address" "$ssh_port" >&2
"$qemu" "${qemu_args[@]}"
